# How to use this zip on Overleaf

1. Overleaf → New Project → **Upload Project** → drop this zip in.
2. Menu → Compiler: **pdfLaTeX**. Main document: **ieeeaccess.tex**.
3. Recompile twice (the second pass resolves table/section cross-references).

It compiles as-is. A local pdfLaTeX build of exactly these files produced a
6-page PDF with no errors and no undefined references.

## What is in here

| File | What it is |
|---|---|
| `ieeeaccess.tex` | the manuscript (main document) |
| `results.tex` | simulator macros, emitted by `npm run test:paper` |
| `realdata.tex` | real-CTIME macros, emitted by `make_realdata_tex.py` |
| `fig_trend.pdf` | Figure 1, emitted by `make_trend_figure.py` |
| `ieeeaccess.cls` | IEEE Access class |
| `IEEEtran.cls` | base IEEE class the Access class loads |
| `logo.png`, `bullet.png`, `notaglinelogo.png` | artwork the Access class draws on page 1 |
| `ieeeaccess.pdf` | the compiled PDF from these exact sources |

Numbers are never typed into the tex by hand. Every figure in the tables comes
from a `\newcommand` in `results.tex` or `realdata.tex`. If you rerun an
experiment, regenerate those two files (and `fig_trend.pdf`) and recompile;
nothing else changes.

Figure 1 uses the class's own `\Figure[...](...)[...]{file}{caption}` macro, not
a plain `figure` environment. The Access class caption code reads a length that
only `\Figure` sets, so a plain environment fails to compile.

## Before you submit — fill these in

Search the tex for `FILL-IN`:

- `\address[1]{... (e-mail: FILL-IN@vitstudent.ac.in)}`
- `\corresp{Corresponding author: S. Haripriya (e-mail: FILL-IN@vitstudent.ac.in).}`

Leave `\history{...}` and `\doi{...}` as the template placeholders. IEEE fills
those at acceptance.

## One class-file note

The preamble contains this guard:

```latex
\makeatletter
\@ifundefined{c@biography}{\newcounter{biography}}{}
\@ifundefined{if@biographyTOCentrynotmade}{\newif\if@biographyTOCentrynotmade\@biographyTOCentrynotmadetrue}{}
\makeatother
```

The copy of `ieeeaccess.cls` in this zip refers to a `biography` counter and a
TOC flag that it never defines, so `\begin{IEEEbiographynophoto}` fails without
this. The guard defines them only when missing, so it is harmless if you later
swap in a newer class file from the official IEEE Access kit. If you do swap the
class, recompile and check page 1 still renders the title block.
