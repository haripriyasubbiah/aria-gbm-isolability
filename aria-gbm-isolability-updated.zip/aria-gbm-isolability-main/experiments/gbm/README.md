# Real Fermi-GBM kill experiment

Public CTIME (NaI) from HEASARC, then the same ARIA residuals as the simulator.

## What to download

You do **not** pick files by hand. `prepare.py` pulls the catalog and the FITS files.

Per trigger it fetches the latest

`glg_ctime_n0…nb_bnYYMMDDfff_vXX.pha`

from

`https://heasarc.gsfc.nasa.gov/FTP/fermi/data/gbm/triggers/20YY/bnYYMMDDfff/current/`

`--per-class 12` → 48 triggers × up to 12 NaI files ≈ **250–400 MB**.  
`--per-class 25` is the paper-sized slice (~0.8 GB).

Do not download TTE for this first kill test. CTIME is enough to see whether a real multi-detector TGF is still rank-1 (not a checksum failure).

## What to install (once)

```bash
python3 -m pip install --user astropy numpy
```

Node deps are already in the repo (`npm install` if needed).

## What to run

From the repo root:

```bash
# 1. Catalog + download + bin 8×64 cubes  (10–30 min depending on HEASARC)
python3 experiments/gbm/prepare.py --per-class 12

# 2. Train linear head on real GRB/SGR/SFLARE, hold out TGF, inject sensor/compute
npm run test:gbm            # 5 training seeds, mean +/- std
python3 experiments/gbm/make_realdata_tex.py
python3 experiments/gbm/make_trend_figure.py
```

Resume-safe: already-downloaded `.pha` files in `experiments/gbm/raw/` are skipped.

## How to read the result

`npm run test:gbm` must print something like:

- `novelAsCompute` near **0** → ARIA still works: a real held-out TGF is not a bit-flip.
- `novelIso` high → morphology still sees TGF as new.
- `sensorIso` / `computeIso` → injected faults on real arrays, not on the simulator.

## Runs so far (this environment)

| Triggers/class | ariaAcc | computeIso | sensorIso | novelAsCompute | novelIso |
|---|---|---|---|---|---|
| 8  | 78.8% | 91.7%  | 75.0% | 0 | 0 |
| 12 | 75.8% | 100.0% | 58.3% | 0 | 0 |
| 25 | 72.8% | 92.5%  | 60.0% | 0 | 0 |

The 25/class row is the mean over training seeds 7, 19, 31, 43, 61 at evaluation
seed 123 (std: acc 0.4, compute 1.6, sensor 0.0 points). The 8 and 12 rows
predate seed averaging and are single-seed runs.

`sensorIso` moved 16.7 points from 8 to 12 and only 1.7 points from 12 to 25, so ~60% is a converged
real-data estimate, not sample noise. `ariaAcc` declines monotonically as the slice grows: larger real
samples pull in harder triggers. The paper quotes the 25/class run, not the flattering first one.

`novelAsCompute` = 0 at every size: the kill test passes on real data (a real TGF is never a bit-flip).
`novelIso` = 0 at every size: CTIME bins are too coarse to name TGF novel, so held-out TGFs land in
known-clean. That needs TTE, not a lower threshold.

## Files written

| Path | What |
|---|---|
| `experiments/gbm/triggers.csv` | HEASARC names + types |
| `experiments/gbm/raw/` | FITS (gitignored, large) |
| `experiments/gbm/cubes.jsonl` | 8-detector × 64-bin cubes |
