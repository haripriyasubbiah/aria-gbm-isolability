# IEEE Access submission checklist (official 18)

Source: https://ieeeaccess.ieee.org/authors/submission-guidelines/

This zip is a **Research Article** in `ieeeaccess.cls`. Filling the template does not guarantee acceptance.

| # | Requirement | Status |
|---|---|---|
| 1 | Double-column, single-spaced, required IEEE Access template. LaTeX **and** PDF, content matching, each &lt; 40 MB | **OK.** `ieeeaccess.cls`, 6 pages, PDF ~260 KB. After any Overleaf edit, download the new PDF so the two files still match. A mismatch is a bounce. |
| 2 | Disclose AI-generated text in Acknowledgements, with a citation to the AI system | **OK in the file.** There is an Acknowledgment plus bibitem `ieeeai2023`. If this PDF is only for course (mam) and you are not uploading to IEEE yet, you may delete that section. **Keep it for a real Access upload.** |
| 3 | Author list final; non-authors go in Acknowledgment | **YOU.** Currently one author: S. Haripriya. If mam (or anyone) contributed enough to be an author, add them **now**. Changing the list after submission is treated as exceptional. |
| 4 | Submitting author: public, populated ORCID | **YOU.** Register at orcid.org, fill affiliation and works, set the profile public, link it in ScholarOne. Nothing in a tex file can do this. |
| 5 | All authors listed in source and PDF; extraction must succeed | **OK** (one author). Check the ScholarOne extraction preview. |
| 6 | Short biography for every author, below the references | **OK.** `IEEEbiographynophoto`. Optional: switch to `IEEEbiography` with a 1 in × 1.25 in photo. |
| 7 | Thorough grammar review; poor grammar is an immediate reject | **YOU.** Run Paperpal Preflight (linked from the Access checklist). Read Limitations and §Real Public CTIME Data aloud once. |
| 8 | Every reference accurate, relevant, not retracted | **PARTLY.** ProGIP (Joshi et al., ACM TECS 24(5s), art. 118, 2025, doi 10.1145/3761796) and BLINK (arXiv:2609.06781) were checked. **Open the other ~18 yourself** and fill missing volume/pages. Highest-risk bounce item. |
| 9 | Not under review elsewhere | **OK** until you submit somewhere. |
| 10 | Supplementary material ready if applicable | **YOU (optional).** The GitHub repo is the natural supplement. Consider a Zenodo snapshot so the URL cannot rot. |
| 11 | Define abbreviations at first use in the body, even if already defined in the abstract | **OK.** GBM, NaI, BGO, OOD, SDC, ABFT, TTE, CTIME, maximum logit score, fast-rise exponential-decay. ARIA is expanded where the method starts. |
| 12 | 3–10 keywords | **OK.** Six. |
| 13 | Select a manuscript type | **YOU — select Research Article.** Do not pick Negative Result: CTIME novel-isolation = 0 is one finding inside a positive result. |
| 14 | Opposed reviewers (optional) | **N/A** unless you have a specific reason. |
| 15 | Video, max 100 MB | **N/A.** |
| 16 | “List of updates” if this is a resubmission after peer review | **N/A.** First submission. |
| 17 | Strongly keep under 20 pages | **OK.** 6. |
| 18 | No Lena image | **OK.** One generated line plot. |

## What the paper actually claims (so you do not over-speak to mam)

- Simulator headline: 89.3±0.3% four-way vs 43.1±6.0% range-check; novelty never named compute.
- Real CTIME (100 cubes, 25/class, five training seeds): 72.8±0.4% accuracy, 60.0% sensor isolation, **novelAsCompute 0**, **novelIso 0**.
- Simulator sensor isolation 77.8% is an **upper bound**, not the real-data headline.
- Known-class train/eval cubes overlap; TGF is held out. Accuracy on known-clean is optimistic. The kill test is not.

## You still do, outside this zip

1. ORCID (item 4).
2. Paperpal grammar pass (item 7).
3. Open every remaining reference (item 8).
4. Decide whether mam is a co-author (item 3).
5. Overleaf compile, then submit the **matching** tex zip + PDF.
