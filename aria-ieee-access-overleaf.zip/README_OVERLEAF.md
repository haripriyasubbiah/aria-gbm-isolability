# Upload this zip to Overleaf

This folder **is** the IEEE Access project. Ignore `files (8).zip`, `files (9).zip`, and the older `aria-ieee-access-overleaf.zip` — those were mixed drafts.

## Overleaf

1. overleaf.com → **New Project** → **Upload Project**
2. Drop **`aria-ieee-access-overleaf.zip`**
3. Menu → Compiler **pdfLaTeX** → Main document **`ieeeaccess.tex`**
4. Recompile **twice**

You should get a **6-page** PDF with the Access header band, blue title, INDEX TERMS, Table 6 (100 public CTIME cubes), Table 7 (8/12/25 trend), and Figure 1.

Leave `\history{...}` and `\doi{...}` as placeholders. IEEE fills those at acceptance.

## What each file is

| File | Role |
|---|---|
| `ieeeaccess.tex` | manuscript (main) |
| `ieeeaccess.cls` + `IEEEtran.cls` | official Access class |
| `logo.png` `bullet.png` `notaglinelogo.png` | page-1 Access artwork |
| `results.tex` | simulator macros (`npm run test:paper`) |
| `realdata.tex` | 100-cube CTIME macros |
| `fig_trend.pdf` | Figure 1 |
| `ieeeaccess.pdf` | compiled PDF of these exact sources (must match the tex at submission) |
| `CHECKLIST_STATUS.md` | official 18-point Access checklist, marked OK / YOU |

Byline is **S. Haripriya**, 24BCE5415, email `hariripriya.subbiah@gmail.com`. No Rithik. No `FILL-IN`.
