# Dataset

Processed cubes only. Raw HEASARC FITS files are not in this zip.

- `experiments/gbm/cubes.jsonl` — first public CTIME draw, 25 triggers in each of GRB, SGR, solar flare, and TGF.
- `experiments/gbm/cubes_draw2.jsonl` — second draw, no shared trigger name.
- `experiments/gbm/tte_cubes_grb_tgf.jsonl` — 1 ms bins for the burst-only morphology (24 flashes; `bn260414904` had no usable file).
- `experiments/gbm/tte_cubes.jsonl` — 1 ms four-family file used by the lookup.
- `experiments/gbm/channel_id.json` — whether the worst detector is the injected detector.
