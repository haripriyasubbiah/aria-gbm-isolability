# IEEE Access manuscript

Upload this zip with New Project, then Upload Project. Main file: ieeeaccess.tex. Compile with pdfLaTeX twice.

First author: Haripriya S.
Corresponding author: Suhasini S. (suhasini.s@vit.ac.in).

The PDF is 15 pages. Every results figure, results table, and reference is included. The acknowledgment thanks HEASARC and states that the work received no specific grant. The declaration of interest follows the acknowledgment.
